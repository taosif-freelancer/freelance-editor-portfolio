import { useScrollReveal } from '../hooks/useScrollReveal'
import { siteConfig } from '../data/siteConfig'
import { focusAreas } from '../data/services'

export default function About() {
  const revealRef = useScrollReveal()

  return (
    <section id="about" ref={revealRef} className="py-24 sm:py-32 border-t border-line">
      <div className="container-custom grid lg:grid-cols-[0.9fr_1.1fr] gap-14 lg:gap-20">
        <div data-reveal className="reveal">
          <p className="eyebrow">About</p>
          <h2 className="mt-3 font-display text-3xl sm:text-4xl text-ink">About Me</h2>

          <p className="mt-6 text-ink-soft leading-relaxed">
            I&rsquo;m a freelance editor, proofreader, formatter, and
            content-improvement specialist based in {siteConfig.location}. I work
            primarily through Fiverr, where I&rsquo;ve completed{' '}
            {siteConfig.projectsCompleted.toLowerCase()} over{' '}
            {siteConfig.experience.toLowerCase()}, across editing, proofreading,
            grammar correction, AI-assisted text humanization, content
            improvement, APA and MLA formatting, and general document
            formatting.
          </p>
          <p className="mt-4 text-ink-soft leading-relaxed">
            My work spans academic writing, business and professional
            documents, articles and blog content, and other general written
            material — the goal in each case is the same: clarity,
            correctness, consistency, and a polished, professional
            presentation.
          </p>

          <div className="mt-8 flex gap-8">
            <div>
              <p className="font-display text-2xl text-ink">1+</p>
              <p className="section-label mt-1">Year of experience</p>
            </div>
            <div>
              <p className="font-display text-2xl text-ink">6+</p>
              <p className="section-label mt-1">Projects completed</p>
            </div>
          </div>
        </div>

        <div data-reveal className="reveal" style={{ transitionDelay: '0.1s' }}>
          <p className="section-label mb-4">What I focus on</p>
          <ul>
            {focusAreas.map((item, index) => (
              <li
                key={item}
                className="flex items-baseline gap-5 py-4 border-t border-line-soft last:border-b"
              >
                <span className="font-mono text-xs text-redline">
                  {String(index + 1).padStart(2, '0')}
                </span>
                <span className="font-display text-xl sm:text-2xl text-ink">
                  {item}
                </span>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </section>
  )
}
