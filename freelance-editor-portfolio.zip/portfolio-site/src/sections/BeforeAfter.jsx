import { useScrollReveal } from '../hooks/useScrollReveal'

const improvements = ['Clarity', 'Conciseness', 'Grammar', 'Flow', 'Readability']

export default function BeforeAfter() {
  const revealRef = useScrollReveal()

  return (
    <section
      id="before-after"
      ref={revealRef}
      className="py-24 sm:py-32 border-t border-line bg-paper-dim"
    >
      <div className="container-custom">
        <div data-reveal className="reveal max-w-xl">
          <p className="eyebrow">Editing Demonstration</p>
          <h2 className="mt-3 font-display text-3xl sm:text-4xl text-ink">
            What an edit actually changes
          </h2>
          <p className="mt-4 text-ink-soft leading-relaxed">
            A fictional example, shown purely to illustrate the kind of change
            an edit makes — not a real client document.
          </p>
        </div>

        <div className="mt-14 grid lg:grid-cols-2 gap-px bg-line border border-line">
          <div data-reveal className="reveal bg-paper p-7 sm:p-9">
            <p className="section-label mb-5">Before</p>
            <p className="font-display text-lg sm:text-xl leading-relaxed text-ink-soft">
              <span className="line-through decoration-redline decoration-2 text-ink-faint">
                Due to the fact that
              </span>{' '}
              the results were{' '}
              <span className="line-through decoration-redline decoration-2 text-ink-faint">
                not very clear
              </span>{' '}
              and{' '}
              <span className="line-through decoration-redline decoration-2 text-ink-faint">
                it was found that there were
              </span>{' '}
              several issues with the overall analysis&hellip;
            </p>
          </div>

          <div data-reveal className="reveal bg-paper p-7 sm:p-9" style={{ transitionDelay: '0.1s' }}>
            <p className="section-label mb-5 text-redline">After</p>
            <p className="font-display text-lg sm:text-xl leading-relaxed text-ink">
              The results were unclear and contained several issues in the
              overall analysis.
            </p>
          </div>
        </div>

        <div data-reveal className="reveal mt-8 flex flex-wrap gap-2">
          {improvements.map((item) => (
            <span
              key={item}
              className="text-xs font-mono uppercase tracking-wide text-redline border border-redline/30 bg-redline-tint px-3 py-1.5 rounded-[2px]"
            >
              {item}
            </span>
          ))}
        </div>
      </div>
    </section>
  )
}
