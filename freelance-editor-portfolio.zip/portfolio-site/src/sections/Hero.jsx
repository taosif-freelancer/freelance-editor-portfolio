import { ArrowRight, ArrowUpRight } from 'lucide-react'
import { siteConfig } from '../data/siteConfig'
import { CaretMark, StrikeMark, CircleMark } from '../components/EditMarks'

export default function Hero() {
  return (
    <section id="home" className="relative pt-32 sm:pt-40 pb-20 sm:pb-28 overflow-hidden">
      <div className="container-custom grid lg:grid-cols-[1.05fr_0.95fr] gap-14 lg:gap-10 items-center">
        {/* Copy column */}
        <div>
          <p
            className="eyebrow animate-fade-up"
            style={{ animationDelay: '0.05s', opacity: 0 }}
          >
            Freelance Editor &middot; Proofreader &middot; Content Specialist
          </p>

          <h1
            className="mt-5 font-display text-[2.6rem] leading-[1.08] sm:text-6xl sm:leading-[1.06] text-ink animate-fade-up"
            style={{ animationDelay: '0.15s', opacity: 0 }}
          >
            Clarity is a craft.
            <br />
            <span className="italic text-redline">I edit for it.</span>
          </h1>

          <p
            className="mt-6 max-w-lg text-base sm:text-lg text-ink-soft leading-relaxed animate-fade-up"
            style={{ animationDelay: '0.25s', opacity: 0 }}
          >
            I help individuals, creators, students, professionals, and businesses
            turn rough drafts into writing that reads clearly, correctly, and
            confidently — through editing, proofreading, formatting, and content
            refinement.
          </p>

          <div
            className="mt-9 flex flex-wrap items-center gap-4 animate-fade-up"
            style={{ animationDelay: '0.35s', opacity: 0 }}
          >
            <a href="#portfolio" className="btn-primary">
              View My Work
              <ArrowRight size={16} />
            </a>
            <a
              href={siteConfig.fiverrUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="btn-outline"
            >
              Hire Me on Fiverr
              <ArrowUpRight size={16} />
            </a>
          </div>

          <p
            className="mt-8 font-mono text-xs uppercase tracking-[0.15em] text-ink-faint animate-fade-up"
            style={{ animationDelay: '0.45s', opacity: 0 }}
          >
            {siteConfig.experience} &middot; {siteConfig.projectsCompleted}
          </p>
        </div>

        {/* Annotated-manuscript visual */}
        <div
          className="relative animate-fade-up"
          style={{ animationDelay: '0.3s', opacity: 0 }}
        >
          <div className="relative border border-line bg-white/60 rounded-[3px] p-6 sm:p-8 shadow-[0_30px_70px_-35px_rgba(30,27,22,0.35)]">
            <div className="flex items-center justify-between mb-7">
              <span className="section-label">Manuscript &mdash; Draft 3</span>
              <span className="font-mono text-[11px] text-ink-faint">
                Track Changes: On
              </span>
            </div>

            <div className="space-y-4">
              <div className="h-2.5 rounded-full bg-ink/10 w-[94%]" />

              <div className="relative">
                <div className="h-2.5 rounded-full bg-ink/10 w-[78%]" />
                <StrikeMark className="absolute -top-1 left-2 w-24 h-3 text-redline/80" />
              </div>

              <div className="h-2.5 rounded-full bg-ink/10 w-[88%]" />

              <div className="flex items-center gap-3">
                <div className="relative shrink-0">
                  <div className="h-2.5 rounded-full bg-ink/10 w-16" />
                  <CircleMark className="absolute -inset-x-2 -inset-y-2 w-[calc(100%+16px)] h-[calc(100%+16px)] text-redline/70" />
                </div>
                <div className="h-2.5 rounded-full bg-ink/10 w-[46%]" />
              </div>

              <div className="relative pt-3">
                <CaretMark className="absolute -top-1 left-10 w-3 h-2 text-redline" />
                <div className="h-2.5 rounded-full bg-ink/10 w-[68%]" />
              </div>

              <div className="h-2.5 rounded-full bg-ink/10 w-[52%]" />

              <div className="rule !bg-line-soft my-5" />

              <div className="h-2.5 rounded-full bg-ink/10 w-[91%]" />
              <div className="h-2.5 rounded-full bg-ink/10 w-[60%]" />
            </div>
          </div>

          {/* Floating margin notes */}
          <div className="hidden sm:flex absolute -right-5 top-8 items-center gap-2 bg-paper border border-line px-3 py-1.5 rounded-[2px] shadow-sm rotate-2">
            <span className="font-mono text-[11px] text-ink-soft">
              insert: &ldquo;clearly&rdquo;
            </span>
          </div>
          <div className="hidden sm:flex absolute -left-6 bottom-16 items-center gap-2 bg-paper border border-line px-3 py-1.5 rounded-[2px] shadow-sm -rotate-2">
            <span className="font-mono text-[11px] text-ink-soft">tighten this line</span>
          </div>
        </div>
      </div>
    </section>
  )
}
