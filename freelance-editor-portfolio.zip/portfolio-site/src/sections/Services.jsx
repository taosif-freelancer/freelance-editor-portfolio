import {
  PenLine,
  Sparkles,
  GraduationCap,
  BookMarked,
  FileText,
  Briefcase,
} from 'lucide-react'
import { useScrollReveal } from '../hooks/useScrollReveal'
import { services } from '../data/services'

const iconMap = { PenLine, Sparkles, GraduationCap, BookMarked, FileText, Briefcase }

export default function Services() {
  const revealRef = useScrollReveal()

  return (
    <section id="services" ref={revealRef} className="py-24 sm:py-32 border-t border-line">
      <div className="container-custom">
        <div data-reveal className="reveal max-w-xl">
          <p className="eyebrow">Services</p>
          <h2 className="mt-3 font-display text-3xl sm:text-4xl text-ink">
            Editing, across the kinds of writing that need it
          </h2>
          <p className="mt-4 text-ink-soft leading-relaxed">
            Academic editing is one part of the work — not the whole of it.
            Here&rsquo;s the full range of what I offer.
          </p>
        </div>

        <div className="mt-14 grid sm:grid-cols-2 lg:grid-cols-3 gap-px bg-line border border-line">
          {services.map((service, index) => {
            const Icon = iconMap[service.icon]
            return (
              <div
                key={service.title}
                data-reveal
                className="reveal group relative bg-paper p-8 sm:p-9 transition-colors duration-300 hover:bg-paper-dim"
                style={{ transitionDelay: `${0.05 * index}s` }}
              >
                <div className="flex items-start justify-between">
                  <div className="inline-flex h-11 w-11 items-center justify-center border border-line text-redline transition-colors duration-300 group-hover:border-redline">
                    {Icon && <Icon size={20} strokeWidth={1.75} />}
                  </div>
                  <span className="font-mono text-xs text-ink-faint">
                    {service.number}
                  </span>
                </div>

                <h3 className="mt-6 font-display text-xl text-ink">
                  {service.title}
                </h3>
                <p className="mt-3 text-sm text-ink-soft leading-relaxed">
                  {service.description}
                </p>

                <div className="mt-6 h-px w-8 bg-redline/40 transition-all duration-300 group-hover:w-14 group-hover:bg-redline" />
              </div>
            )
          })}
        </div>
      </div>
    </section>
  )
}
