// Small hand-style proofreading marks used as the site's recurring visual
// signature — caret (insertion), strike (deletion), circle (flag), and the
// paragraph mark. Pure SVG, no external assets.

export function CaretMark({ className = '' }) {
  return (
    <svg viewBox="0 0 24 16" className={className} aria-hidden="true">
      <path
        d="M2 14 L12 3 L22 14"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  )
}

export function StrikeMark({ className = '' }) {
  return (
    <svg viewBox="0 0 120 12" className={className} preserveAspectRatio="none" aria-hidden="true">
      <path
        d="M2 6 C 30 2, 60 10, 90 5 S 115 3, 118 6"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
      />
    </svg>
  )
}

export function CircleMark({ className = '' }) {
  return (
    <svg viewBox="0 0 100 44" className={className} preserveAspectRatio="none" aria-hidden="true">
      <path
        d="M50 3 C20 1 3 12 4 23 C5 35 24 42 52 41 C82 40 97 31 96 20 C95 9 76 2 50 3"
        fill="none"
        stroke="currentColor"
        strokeWidth="2.5"
        strokeLinecap="round"
      />
    </svg>
  )
}

export function ParagraphMark({ className = '' }) {
  return (
    <span aria-hidden="true" className={`font-display italic select-none ${className}`}>
      ¶
    </span>
  )
}

export function UnderlineSquiggle({ className = '' }) {
  return (
    <svg viewBox="0 0 120 10" className={className} preserveAspectRatio="none" aria-hidden="true">
      <path
        d="M1 6 Q 10 1, 20 6 T 40 6 T 60 6 T 80 6 T 100 6 T 119 6"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
      />
    </svg>
  )
}
